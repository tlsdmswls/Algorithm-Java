package socket.server;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Random;

/* 데이터 손실 시뮬레이터용 객체 */
public class ServerSimulator {
	Random rd = new Random();
	Client c = null;
	Socket socket;
	
//	ServerSimulator(Socket _s, Client _c) {
//		socket = _s;
//		c = _c;
//	}
	
	ServerSimulator(Socket _s) {
		socket = _s;
	}
	
	
	/* 클라이언트로 Message를 전송하는 메소드 */
	public void sendMessage(String msg) {
		int if_write = rd.nextInt(10);
		try {
			if(if_write < 7) {
				OutputStream out = socket.getOutputStream();
				DataOutputStream dout = new DataOutputStream(out);
				
				dout.writeUTF(msg);
				dout.flush();
				System.out.println(msg);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}